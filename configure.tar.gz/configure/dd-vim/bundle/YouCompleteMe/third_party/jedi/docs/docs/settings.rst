.. include:: ../global.rst

Settings
========

.. automodule:: settings
