﻿namespace OmniSharp.ContextInformation
{
    public class GetContextResponse
    {
        public string MethodName { get; set; }
        public string AssemblyName { get; set; }
        public string TypeName { get; set; }
    }
}