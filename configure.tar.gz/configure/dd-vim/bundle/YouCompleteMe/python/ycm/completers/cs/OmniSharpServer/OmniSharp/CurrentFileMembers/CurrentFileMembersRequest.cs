﻿using OmniSharp.Common;

namespace OmniSharp.CurrentFileMembers {
    public class CurrentFileMembersRequest : Request {}
}
